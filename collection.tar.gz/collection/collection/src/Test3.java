public class Test3 {
   static char check[];
   static int count=1,f=0;
   static int occ[],h=0;
    public static void unichar(String s)
    {
        s=s.replaceAll(" ","");
         check=new char[(int)s.chars().distinct().count()];
        occ=new int[(int)s.chars().distinct().count()];
        occchar(s);
    }
    
     public static void occchar(String s)
    {
        for(int i=0;i<s.length();i++)
        {
            char c=s.charAt(i);
           if(!checked(c)&&c!=' ')
           { 
               for(int k=i+1;k<s.length();k++) 
               {
                   if(c==s.charAt(k))
                   {
                       count++;
                       f=1;
                   }
               }
               
                   check[h]=c;
                   occ[h]=count;
                   h++;
              
            }
           count=1;
           f=0;
        }
        print();
    }
     public static boolean checked(char c)
     {
         
         boolean flag=false;
         for(int j=0;j<check.length;j++)
         {
             if(c==check[j])
             {
                flag=true;
                j=check.length;
             }
         }
         return flag;
     }
     public static void print()
     {
         for(int i=0;i<check.length;i++)
         {
             System.out.println("character "+check[i]+" has "+occ[i]+" no. of occurence ");
         }
     }
    public static void main(String[] args) {
        unichar("       a        b    c        d      a a a    " ) ;
}
}
