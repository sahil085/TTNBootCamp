
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

public class Test5 {
    String name="";
    double score=0.0,age=0.0;
 static ArrayList al;
    public Test5(String name,double score,double age) {
        this.name=name;
        this.score=score;
        this.age=age;
                
    }
    public static void main(String[] args) {
       al=new ArrayList();
        al.add(new Test5("radha",97.5,23.5));
        al.add(new Test5("krishna",97.5,22.5));
        al.add(new Test5("sahil",7.5,22.5));
        al.add(new Test5("ayushi",1.5,23.5));                                                                    
        Collections.sort(al,new score());    
        for(int i=0;i<al.size();i++)
        {
            Test5 s=(Test5)al.get(i);
            System.out.println(s.name+" "+s.score+" "+s.age);
        }
    } 
}
class score implements Comparator<Test5>
{
    @Override
    public int compare(Test5 o1, Test5 o2) {
      if(o1.score==o2.score)
      {
          return  o1.name.compareTo(o2.name);
      }
      else if(o1.score>o2.score)
      {
           return 1;       
      }
      else
      {
          return -1;
      }       
    }
    
}