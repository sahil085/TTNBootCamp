public class test7 {
    static 
    {
        System.out.println("name and age using static block");
        System.out.println("first name is sahil \nlast name is verma \n age is 22");
    }
    public static void print()
    {
         System.out.println("name and age using static method");
        System.out.println("first name is sahil \nlast name is verma \n age is 22");
    }
    static String fname="radha";
    static String lname="krishna";
    static int age=22;
    public static void main(String[] args) {
        System.out.println("name and age using static variable ");
        System.out.println("first name "+fname);
        System.out.println("last name is "+lname);
        System.out.println("age is "+age);
        print();
}
}
