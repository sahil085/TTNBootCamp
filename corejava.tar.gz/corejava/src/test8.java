public class test8 {
    public static void main(String[] args) {
   StringBuffer sb=new StringBuffer("abcdefghijkl");
   sb=sb.reverse();
   String s=sb.delete(4,9).toString();
        System.out.println(s);
}
}
