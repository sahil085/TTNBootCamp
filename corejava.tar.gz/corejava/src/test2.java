public class test2 {
    public static void main(String[] args) {
   String s="    @ @   aa aaa aaaaaa aa aa aa a a a a a a   a   #    aa   #   aaa aaaaaa   aa  a a aaaa        ";
    String words[]=s.split(" ");
    int jj=0,kk=0;

  
   String duplicatewords[]=new String[words.length];
   int count[]=new int[words.length];
   int occ=1,flag=0,k=0,f=0;
   for(int i=0;i<words.length;i++)
   {
       String w=words[i];

      if(!w.matches("^\\s*$"))
       {
       for(int h=0;h<duplicatewords.length;h++)
       {
           if(w.equals(duplicatewords[h]))
           {
               f=1;
               h=duplicatewords.length;
           }
       }
       if(f==0)
       {
       for(int j=i+1;j<words.length;j++)
       {
           if(w.equals(words[j]))
           {
               occ=occ+1;
               flag=1;
           }
           
       }
       }
       if(flag==1)
       {
           duplicatewords[k]=w;
           count[k]=occ;
           occ=1;
           k++;
           flag=0;
           
       }
       }
       f=0;
       
   }
   for(k=0;k<count.length;k++)
   {
       if(count[k]!=0)
       {
       System.out.println(" word "+duplicatewords[k]+" comes "+count[k]);
       }
   }
   
   
}
}
