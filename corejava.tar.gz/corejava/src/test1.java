

import java.util.Scanner;

public class test1 {

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter String");
        String input=scanner.nextLine();
        System.out.println("Enter Starting Index");
        int start=scanner.nextInt();
        if(start<0||start>input.length())
        {
            System.out.println("index out of index try again");
            System.exit(0);
        }
        System.out.println("Enter Ending Index");
        int end=scanner.nextInt();
        if(end<0||end>input.length())
        {
            System.out.println("index out of index try again");
            System.exit(0);
        }
       

        scanner.nextLine();
        System.out.println("Enter String To Replace");
        String stringtoreplacewith=scanner.nextLine();
        String stringtoreplace=input.substring(start,end);
        input=input.replace(stringtoreplace,stringtoreplacewith);
        System.out.println(input);
    }
}
s
