
import java.util.Scanner;

public class test3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the string");
   String ss=sc.nextLine();
        System.out.println("enter the character to find it's occurrences");
        String ch=sc.next();
        if(ch.length()>1)
        {
            System.out.println("enter a single character");
            main(args);
        }
        else
        {
    int c=ss.length()-ss.replaceAll(ch, "").length();
        System.out.println(c);
        }
}
}
